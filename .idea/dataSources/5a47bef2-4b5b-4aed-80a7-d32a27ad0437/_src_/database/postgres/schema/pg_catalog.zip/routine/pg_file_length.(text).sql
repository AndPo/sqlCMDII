create function pg_file_length(text) returns bigint
LANGUAGE SQL
AS $$
SELECT size FROM pg_catalog.pg_stat_file($1)
$$;
